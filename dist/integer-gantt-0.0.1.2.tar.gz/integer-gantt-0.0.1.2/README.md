# integer-gantt

### \*\* Requires the following external dependencies! you will need npm to install these!

```bash
npm install -g electron@1.8.4 orca
```

## Info

I have a problem where I needed a relative gantt chart for a quick project proposal, nothing fancy.

I couldn't find a way to generate a nice gantt chart without 'datetimes' on it!!

I finally found a way to do it on [stack overflow](https://stackoverflow.com/a/51124342/9510611) and decided to implement it in a nice little package in case I need it again.

Literally the only thing this package does is create a gantt chart locally using ploty and input form a json file.

### I might add other fuctionality later, I might not!
